#ifndef __ANSWER__

typedef struct _Elmore_delay_info{
    double elmore_delay;
    double capacitance_sum_below;
    double head_resistance;
    double left_stage_delay;
    double right_stage_delay;

}Elmore_delay_info;

typedef struct _TreeNode{
    double sink_cap;
    int sink_number;
    int number_of_inverter;
    double node_capacitace;
    int node_type;
    Elmore_delay_info Elmore;
    double left_edge_length;
    double right_edge_length;
    struct _TreeNode* left;
    struct _TreeNode* right;
}TreeNode;


typedef struct _LinkedList{
    TreeNode* tree;
    struct _LinkedList* next;
}LinkedList;

typedef struct _CircuitInfo{
    double Time_constraint;
    double Res_per_Length;
    double Cap_per_Length;
    double input_cap;
    double output_res;
    double output_cap;
    TreeNode* main_tree;
}CircuitInfo;


void Reading_input1(FILE* fp,CircuitInfo* circuit_info);
void Reading_input2(FILE* fp,CircuitInfo* circuit_info);
void Reading_input3(FILE* fp,CircuitInfo* circuit_info);

void output_file1_pre(FILE* fp,TreeNode* main_tree);
void output_file2_elmore(FILE* fp,TreeNode* main_tree);

void elmore_delay_cal(CircuitInfo *circuit_info,FILE* fp);

double insert_inverter(CircuitInfo* circuit_info, TreeNode** tree,TreeNode** parent_tree,int child_dir);


void print_tree(TreeNode *main_tree);

void tree_destroy(TreeNode *list);



#endif