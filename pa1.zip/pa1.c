#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include "math.h"
#include "pa1.h"

void Reading_input1(FILE *fp, CircuitInfo *circuit_info)
{
    int x = fscanf(fp, "%le %le %le\n", &circuit_info->input_cap, &circuit_info->output_cap, &circuit_info->output_res);
    if (x != 3)
    {
        free(circuit_info);
        fclose(fp);
        return;
    }
    fclose(fp);
    return;
}

void Reading_input2(FILE *fp, CircuitInfo *circuit_info)
{
    int x = fscanf(fp, "%le %le\n", &circuit_info->Res_per_Length, &circuit_info->Cap_per_Length);
    if (x != 2)
    {
        free(circuit_info);
        fclose(fp);
        return;
    }
    fclose(fp);
    return;
}

static void linked_list_push(LinkedList **List, TreeNode *Node)
{
    TreeNode *tree = Node;
    LinkedList *list = *List;
    if (List == NULL)
    {
        list = malloc(sizeof(*List));
        list->tree = tree;
        list->next = NULL;
    }
    else
    {
        LinkedList *temp = malloc(sizeof(*temp));
        temp->tree = tree;
        temp->next = list;
        list = temp;
    }
    *List = list;
    return;
}

static TreeNode *linked_list_pop(LinkedList **List)
{
    LinkedList *list = *List;

    if (List == NULL)
    {
        return NULL;
    }
    TreeNode *result = list->tree;
    LinkedList *temp = list;
    list = list->next;
    free(temp);
    *List = list;
    return result;
}

void Reading_input3(FILE *fp, CircuitInfo *ciruit_info)
{
    LinkedList *list = NULL;
    TreeNode *left_node = NULL;
    TreeNode *central_node = NULL;

    while (true)
    {
        int c = fgetc(fp);
        if (c == EOF)
        {
            break;
        }
        if (c == 40)
        {
            central_node = malloc(sizeof(*central_node));
            central_node->node_type = 0;
            central_node->number_of_inverter = 0;
            central_node->sink_number = -1;
            int x = fscanf(fp, "%le %le)\n", &central_node->left_edge_length, &central_node->right_edge_length);
            if (x != 2)
            {
                free(ciruit_info);
                fclose(fp);
                return;
            }
            central_node->right = linked_list_pop(&list);
            central_node->left = linked_list_pop(&list);
            linked_list_push(&list, central_node);
        }
        else
        {
            ungetc(c, fp);
            left_node = malloc(sizeof(*left_node));
            left_node->node_type = 1;
            left_node->number_of_inverter = 0;
            left_node->left = NULL;
            left_node->right = NULL;
            left_node->left_edge_length = 0;
            left_node->right_edge_length = 0;
            int x = fscanf(fp, "%d(%le)\n", &left_node->sink_number, &left_node->sink_cap);
            if (x != 2)
            {
                free(ciruit_info);
                fclose(fp);
                return;
            }
            linked_list_push(&list, left_node);
        }
    }
    ciruit_info->main_tree = linked_list_pop(&list);
    fclose(fp);
    return;
}

void output_file1_pre(FILE *fp, TreeNode *main_tree)
{
    TreeNode *circuit_tree = main_tree;
    if (circuit_tree->left == NULL)
    {
        fprintf(fp, "%d(%.10le)\n", circuit_tree->sink_number, circuit_tree->sink_cap);
        return;
    }
    if (circuit_tree != NULL)
    {
        fprintf(fp, "(%.10le %.10le)\n", circuit_tree->left_edge_length, circuit_tree->right_edge_length);
        output_file1_pre(fp, circuit_tree->left);
        output_file1_pre(fp, circuit_tree->right);
    }
    return;
}

void print_tree(TreeNode *main_tree)
{
    TreeNode *circuit_tree = main_tree;
    if(circuit_tree == NULL){
        return;
    }
    print_tree(circuit_tree->left);
    print_tree(circuit_tree->right);
    if(circuit_tree->node_type == 1){
        printf("%d(%d)\n", circuit_tree->sink_number, circuit_tree->node_type);
        return;
    }

    printf("%d (%.10le,%.10le)\n", circuit_tree->node_type,circuit_tree->left_edge_length,circuit_tree->right_edge_length);

    return;
}

void output_file2_elmore(FILE *fp, TreeNode *main_tree)
{
    TreeNode *circuit_tree = main_tree;
    if (circuit_tree->left == NULL)
    {
        fwrite(&circuit_tree->sink_number, sizeof(int), 1, fp);
        fwrite(&circuit_tree->Elmore.elmore_delay, sizeof(double), 1, fp);
        // printf("%d (%.10le)\n", circuit_tree->sink_number, circuit_tree->Elmore.elmore_delay);
        return;
    }
    output_file2_elmore(fp, circuit_tree->left);
    output_file2_elmore(fp, circuit_tree->right);
    // printf("%d (%.10le)\n", circuit_tree->sink_number, circuit_tree->Elmore.elmore_delay);
    return;
}

static void capacitance_cal(TreeNode *main_tree, CircuitInfo *circuit_info, double wire_length)
{
    TreeNode *tree_node = main_tree;
    if (tree_node == NULL)
    {
        return;
    }
    capacitance_cal(tree_node->left, circuit_info, tree_node->left_edge_length);
    capacitance_cal(tree_node->right, circuit_info, tree_node->right_edge_length);
    if (tree_node->node_type == 1)
    {
        tree_node->node_capacitace = tree_node->sink_cap + (wire_length * circuit_info->Cap_per_Length) / 2;
        tree_node->Elmore.head_resistance = (wire_length * circuit_info->Res_per_Length);
        tree_node->Elmore.capacitance_sum_below = tree_node->node_capacitace;
    }
    else
    {
        tree_node->node_capacitace = ((wire_length + tree_node->left_edge_length + tree_node->right_edge_length) * circuit_info->Cap_per_Length) / 2;
        tree_node->Elmore.head_resistance = (wire_length * circuit_info->Res_per_Length);
        tree_node->Elmore.capacitance_sum_below = tree_node->left->Elmore.capacitance_sum_below + tree_node->right->Elmore.capacitance_sum_below + tree_node->node_capacitace;
    }
    return;
}

static void elmore_final_calc(TreeNode *main_tree, double prev_delay)
{
    TreeNode *tree_node = main_tree;
    if (tree_node == NULL)
    {
        return;
    }
    double delay = prev_delay + (tree_node->Elmore.capacitance_sum_below * tree_node->Elmore.head_resistance);
    elmore_final_calc(main_tree->left, delay);
    elmore_final_calc(main_tree->right, delay);
    tree_node->Elmore.elmore_delay = delay;
    return;
}

void elmore_delay_cal(CircuitInfo *circuit_info, FILE *fp)
{
    TreeNode *main_tree = circuit_info->main_tree;
    capacitance_cal(main_tree, circuit_info, 0);
    main_tree->Elmore.head_resistance = circuit_info->output_res;
    main_tree->Elmore.capacitance_sum_below += circuit_info->output_cap;

    elmore_final_calc(circuit_info->main_tree, 0);
    output_file2_elmore(fp, main_tree);
}

static double quad_solver(double a, double b, double c)
{
    double ans1 = (-1 * b + sqrt(pow(b, 2) - 4 * a * c)) / (2 * a);
    double ans2 = (-1 * b - sqrt(pow(b, 2) - 4 * a * c)) / (2 * a);
    printf("length %.10le %.10le\n",ans1,ans2);

    if (ans1 < 0 && ans2 < 0)
    {
        printf("No solution\n");
        return 0;
    }
    if (ans1 < 0)
    {
        return ans2;
    }
    return ans1;
}

static double max(double number1, double number2)
{
    if (number1 >= number2)
    {
        return number1;
    }
    return number2;
}


static void insert_inverter_on_top(CircuitInfo *circuit_info, TreeNode **tree, TreeNode **parent_tree,int child_dir){
        TreeNode *main = *tree;
        TreeNode *parent_main = *parent_tree;
        double a = (circuit_info->Res_per_Length * circuit_info->Cap_per_Length) / 2;
        double b = (circuit_info->output_res * circuit_info->Cap_per_Length / 2 + circuit_info->Res_per_Length * ((circuit_info->Cap_per_Length * (main->left_edge_length + main->right_edge_length) / 2) + main->Elmore.capacitance_sum_below - main->node_capacitace));
        double c = (max(main->Elmore.left_stage_delay, main->Elmore.right_stage_delay) + (circuit_info->output_res * (circuit_info->output_cap + main->Elmore.capacitance_sum_below)) - circuit_info->Time_constraint);
        double length = quad_solver(a, b, c);
        double num_of_inverter =1;
        if(length > (main->Elmore.head_resistance/circuit_info->Res_per_Length)){
            double edge = main->Elmore.head_resistance / circuit_info->Res_per_Length;
            // num_of_inverter = -1 *((circuit_info->output_res* ((circuit_info->Cap_per_Length * parent_main->left_edge_length / 2) + main->Elmore.capacitance_sum_below)) / (a* pow(parent_main->left_edge_length,2) + (c - main->Elmore.capacitance_sum_below) + (parent_main->left_edge_length * (b - (circuit_info->output_res * circuit_info->Cap_per_Length  *parent_main->left_edge_length/ 2)))));
            num_of_inverter += -1*(circuit_info->output_res * (circuit_info->Cap_per_Length/2 + main->Elmore.capacitance_sum_below))/(a* pow(edge,2)  + (b - circuit_info->output_res * (circuit_info->Cap_per_Length/2))* edge + (c - circuit_info->output_res * main->Elmore.capacitance_sum_below));
            printf("%f\n",num_of_inverter);
            num_of_inverter  =ceil(num_of_inverter);
            b = (circuit_info->output_res * circuit_info->Cap_per_Length / (2 * num_of_inverter)+ circuit_info->Res_per_Length * ((circuit_info->Cap_per_Length * (main->left_edge_length + main->right_edge_length) / 2) + main->Elmore.capacitance_sum_below - main->node_capacitace));
            c = (max(main->Elmore.left_stage_delay, main->Elmore.right_stage_delay) + (circuit_info->output_res * (circuit_info->output_cap + main->Elmore.capacitance_sum_below/ num_of_inverter)) - circuit_info->Time_constraint);
            length = quad_solver(a, b, c);
            // printf("%f\b",num_of_inverter);
            // double a = (circuit_info->Res_per_Length * circuit_info->Cap_per_Length) / 2;
            // double b = (circuit_info->output_res*5 * circuit_info->Cap_per_Length / 2 + circuit_info->Res_per_Length * (circuit_info->Cap_per_Length * (main->left_edge_length + main->right_edge_length) / 2));
            // double c = (max(main->Elmore.left_stage_delay, main->Elmore.right_stage_delay) + circuit_info->output_res * circuit_info->output_cap - circuit_info->Time_constraint);
            // double length = quad_solver(a, b, c);
        }
        TreeNode *inverter_node = malloc(sizeof(*inverter_node));
        inverter_node->left = main;
        inverter_node->right = NULL;
        inverter_node->left_edge_length = length;
        inverter_node->node_type = 2;
        inverter_node->number_of_inverter = num_of_inverter;
        inverter_node->sink_cap = circuit_info->input_cap* num_of_inverter;
        inverter_node->node_capacitace = ((circuit_info->Cap_per_Length * length) / 2 + (circuit_info->output_cap * num_of_inverter));
        inverter_node->Elmore.capacitance_sum_below = inverter_node->node_capacitace;
        if (child_dir)
        {
            parent_main->right = inverter_node;
            parent_main->right_edge_length = parent_main->right_edge_length - length;
            parent_main->Elmore.capacitance_sum_below -= main->Elmore.capacitance_sum_below - (circuit_info->input_cap*inverter_node->number_of_inverter + circuit_info->Cap_per_Length * (parent_main->right_edge_length) / 2);
        }
        else
        {
            parent_main->left = inverter_node;
            parent_main->left_edge_length = parent_main->left_edge_length - length;
            parent_main->Elmore.capacitance_sum_below -= main->Elmore.capacitance_sum_below - (circuit_info->input_cap*inverter_node->number_of_inverter + circuit_info->Cap_per_Length * (parent_main->left_edge_length) / 2);
        }
        main->Elmore.head_resistance = circuit_info->Res_per_Length * length;
        *parent_tree = parent_main;
        *tree = inverter_node;
        return;
}
double insert_inverter(CircuitInfo *circuit_info, TreeNode **tree, TreeNode **parent_tree, int child_dir)
{
    TreeNode *main = *tree;
    TreeNode *parent_main;
    if (parent_tree == NULL)
    {
        parent_main = NULL;
    }
    else
    {
        parent_main = *parent_tree;
    }
    if (main == NULL)
    {
        return 0;
    }

    main->Elmore.left_stage_delay = insert_inverter(circuit_info, &(main->left), &(main), 0);
    main->Elmore.right_stage_delay = insert_inverter(circuit_info, &(main->right), &(main), 1);
    // if (main->node_type != 1)
    // {
    //     main->Elmore.capacitance_sum_below = main->left->Elmore.capacitance_sum_below + main->right->Elmore.capacitance_sum_below + main->node_capacitace;
    // }

    if ((circuit_info->Time_constraint - (main->Elmore.capacitance_sum_below * main->Elmore.head_resistance) - max(main->Elmore.left_stage_delay,main->Elmore.right_stage_delay)) < 0)
    {
        if((circuit_info->Time_constraint - (main->Elmore.capacitance_sum_below * main->Elmore.head_resistance) - main->Elmore.left_stage_delay) < 0){
            insert_inverter_on_top(circuit_info,&(main->left),&main,0);
        }
        if((circuit_info->Time_constraint - (main->Elmore.capacitance_sum_below * main->Elmore.head_resistance) - main->Elmore.right_stage_delay) < 0){
            insert_inverter_on_top(circuit_info,&(main->right),&main,1);
        }
        return main->Elmore.capacitance_sum_below * circuit_info->Res_per_Length;
        
        // double a = (circuit_info->Res_per_Length * circuit_info->Cap_per_Length) / 2;
        // double b = (circuit_info->output_res * circuit_info->Cap_per_Length / 2 + circuit_info->Res_per_Length * (circuit_info->Cap_per_Length * (main->left_edge_length + main->right_edge_length) / 2));
        // double c = (max(left_delay_capacitance, right_delay_capacitance) + circuit_info->output_res * circuit_info->output_cap - circuit_info->Time_constraint);
        // double length = quad_solver(a, b, c);
        // if(length > (main->Elmore.head_resistance/circuit_info->Res_per_Length)){
        //     double a = (circuit_info->Res_per_Length * circuit_info->Cap_per_Length) / 2;
        //     double b = (circuit_info->output_res*3 * circuit_info->Cap_per_Length / 2 + circuit_info->Res_per_Length * (circuit_info->Cap_per_Length * (main->left_edge_length + main->right_edge_length) / 2));
        //     double c = (max(left_delay_capacitance, right_delay_capacitance) + circuit_info->output_res * circuit_info->output_cap - circuit_info->Time_constraint);
        //     double length = quad_solver(a, b, c);
        // }
        // TreeNode *inverter_node = malloc(sizeof(*inverter_node));
        // inverter_node->left = main;
        // inverter_node->right = NULL;
        // inverter_node->left_edge_length = length;
        // inverter_node->node_type = 2;
        // inverter_node->sink_cap = circuit_info->input_cap;
        // inverter_node->node_capacitace = ((circuit_info->Cap_per_Length * length) / 2 + circuit_info->output_cap);
        // inverter_node->Elmore.capacitance_sum_below = inverter_node->node_capacitace;
        // if (child_dir)
        // {
        //     parent_main->right = inverter_node;
        //     parent_main->right_edge_length = parent_main->right_edge_length - length;
        //     parent_main->Elmore.capacitance_sum_below -= main->Elmore.capacitance_sum_below - (circuit_info->input_cap + circuit_info->Cap_per_Length * (parent_main->right_edge_length) / 2);
        // }
        // else
        // {
        //     parent_main->left = inverter_node;
        //     parent_main->left_edge_length = parent_main->left_edge_length - length;
        //     parent_main->Elmore.capacitance_sum_below -= main->Elmore.capacitance_sum_below - (circuit_info->input_cap + circuit_info->Cap_per_Length * (parent_main->left_edge_length) / 2);
        // }
        // main->Elmore.head_resistance = circuit_info->Res_per_Length * length;
        // *parent_tree = parent_main;
        // *tree = inverter_node;
        // return inverter_node->Elmore.head_resistance * inverter_node->Elmore.capacitance_sum_below;
    }

    *parent_tree = parent_main;
    *tree = main;
    return (main->Elmore.head_resistance * main->Elmore.capacitance_sum_below) + max(main->Elmore.left_stage_delay,main->Elmore.right_stage_delay);
}

void tree_destroy(TreeNode *list)
{
    TreeNode *a = list;
    if (a->left != NULL)
    {
        tree_destroy(a->left);
    }
    if (a->right != NULL)
    {
        tree_destroy(a->right);
    }
    free(a);
    return;
}