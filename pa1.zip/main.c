#include <stdio.h>
#include <stdlib.h>
#include "pa1.h"

int main(int argc, char **argv)
{
    if (argc != 9)
    {
        return EXIT_FAILURE;
    }

    
    FILE *fp1 = fopen(argv[2], "r");
    if (fp1 == NULL)
    {
        return EXIT_FAILURE;
    }
    CircuitInfo* circuit_info;
    circuit_info = malloc(sizeof(*circuit_info));
    // circuit_info->Time_constraint = strtol(argv[1],NULL,1);
    circuit_info->Time_constraint = atof(argv[1]);
    Reading_input1(fp1,circuit_info); 
    FILE *fp2 = fopen(argv[3], "r");
    if (fp2 == NULL)
    {
        return EXIT_FAILURE;
    }
    Reading_input2(fp2,circuit_info); 

    FILE *fp3 = fopen(argv[4], "r");
    if (fp3 == NULL)
    {
        return EXIT_FAILURE;
    }

    Reading_input3(fp3,circuit_info);
    
    // printf("%.10le %.10le %.10le %.10le %.10le\n", circuit_info->input_res,circuit_info->output_res,circuit_info->output_cap,circuit_info->Res_per_Length,circuit_info->Cap_per_Length);
    
    FILE *fp4 = fopen(argv[5], "w");
    if (fp4 == NULL)
    {
        return EXIT_FAILURE;
    }
    output_file1_pre(fp4,circuit_info->main_tree);
    fclose(fp4);

    FILE *fp5 = fopen(argv[6], "w");
    if (fp5 == NULL)
    {
        return EXIT_FAILURE;
    }
    elmore_delay_cal(circuit_info,fp5);
    fclose(fp5);

    // insert_inverter(circuit_info,&(circuit_info->main_tree),&(circuit_info->main_tree),0);

    FILE *fp6 = fopen(argv[7], "w");
    if (fp6 == NULL)
    {
        tree_destroy(circuit_info->main_tree);
        free(circuit_info);
        return EXIT_FAILURE;
    }
    fclose(fp6);

    FILE *fp7 = fopen(argv[8], "w");
    if (fp7 == NULL)
    {
            tree_destroy(circuit_info->main_tree);
        free(circuit_info);
        return EXIT_FAILURE;
    }
    fclose(fp7);
    // print_tree(circuit_info->main_tree);
    // %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    tree_destroy(circuit_info->main_tree);
    free(circuit_info);
    return EXIT_SUCCESS;
    
}